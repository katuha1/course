// --- аккордион ---
const accordionHeaders = document.querySelectorAll('.accordion-header');

accordionHeaders.forEach(header => {
    header.addEventListener('click', function () {
        const currentItem = this.parentElement;
        const isOpen = currentItem.classList.contains('open');

        accordionHeaders.forEach(header => {
            header.parentElement.classList.remove('open');
            header.nextElementSibling.style.display = 'none';
        });

        if (!isOpen) {
            currentItem.classList.add('open');
            currentItem.querySelector('.accordion-content').style.display = 'block';
        }
    });
});

// регистрация
document.getElementById('openModalBtn').addEventListener('click', function () {
    document.querySelector('.modal-window').style.display = 'flex';
});

document.getElementsByClassName('close')[0].addEventListener('click', function () {
    document.querySelector('.modal-window').style.display = 'none';
});

function openTab(tabName) {
    var i, tabContent;

    tabContent = document.getElementsByClassName('modal-body');
    for (i = 0; i < tabContent.length; i++) {
        tabContent[i].style.display = 'none';
    }

    document.getElementById(tabName).style.display = 'flex';
}



// Модальное окно направления
// -------------1----------------
// Function to open the modal
function openModal_dir1() {
    modal_dir1.style.display = 'block';
}

// Function to close the modal
function closeModal_dir1() {
    modal_dir1.style.display = 'none';
}

// Close the modal when clicking outside of it
window.onclick = function (event) {
    if (event.target == modal_dir1) {
        modal_dir1.style.display = 'none';
    }
}
// -------------2--------------
// Function to open the modal
function openModal_dir2() {
    modal_dir2.style.display = 'block';
}

// Function to close the modal
function closeModal_dir2() {
    modal_dir2.style.display = 'none';
}

// Close the modal when clicking outside of it
window.onclick = function (event) {
    if (event.target == modal_dir2) {
        modal_dir2.style.display = 'none';
    }
}

// ----------------3------------
// Function to open the modal
function openModal_dir3() {
    modal_dir3.style.display = 'block';
}

// Function to close the modal
function closeModal_dir3() {
    modal_dir3.style.display = 'none';
}

// Close the modal when clicking outside of it
window.onclick = function (event) {
    if (event.target == modal_dir3) {
        modal_dir3.style.display = 'none';
    }
}

// ----------------4------------
// Function to open the modal
function openModal_dir4() {
    modal_dir4.style.display = 'block';
}

// Function to close the modal
function closeModal_dir4() {
    modal_dir4.style.display = 'none';
}

// Close the modal when clicking outside of it
window.onclick = function (event) {
    if (event.target == modal_dir4) {
        modal_dir4.style.display = 'none';
    }
}


// Отзывы
const sliderContent = document.querySelector('.slider-content');
const slides = document.querySelectorAll('.slide');
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');
let slideIndex = 0;

showSlide(slideIndex);

function showSlide(index) {
    if (index >= slides.length) {
        slideIndex = 0;
    } else if (index < 0) {
        slideIndex = slides.length - 1;
    }

    sliderContent.style.transform = `translateX(-${slideIndex * 100}%)`;
}

prevBtn.addEventListener('click', function() {
    slideIndex--;
    showSlide(slideIndex);
});

nextBtn.addEventListener('click', function() {
    slideIndex++;
    showSlide(slideIndex);
});


// --- Карта ---
const worktop = document.querySelector('.MapSurface');
const mapcover = document.querySelector('.map_cover');
let isOpenMap = false;

mapcover.addEventListener('click', () => {
    mapcover.style.display = 'none';
    isOpenMap = true;
});

worktop.addEventListener('mouseleave', () => {
    console.log('Мышка вышла из рабочего поля');
    if (isOpenMap && (!mapcover.style.display || mapcover.style.display === 'none')) {
        mapcover.style.display = 'flex';
    }
});
// ---